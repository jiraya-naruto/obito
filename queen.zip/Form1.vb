﻿Imports Microsoft.Web.WebView2.Core

Public Class Form1
    ' When the form is loaded, it will be fullscreen and mouse will be disabled
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set the form to be full-screen and disable minimize, close buttons
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        Me.TopMost = True ' Keep the form on top

        ' Dock the WebView2 control to fill the entire form
        WebView21.Dock = DockStyle.Fill

        ' Initialize WebView2 and load the local HTML file or URL
        InitializeWebView2()
    End Sub

    ' Initialize WebView2 and load the exam content
    Private Async Sub InitializeWebView2()
        Await WebView21.EnsureCoreWebView2Async(Nothing)

        ' Load your local HTML file (replace with the actual file path)
        Dim localHtmlFile As String = "file:///C:\Users\DELL\source\repos\queen\Html/hack.html" ' Update this path

        WebView21.CoreWebView2.Navigate(localHtmlFile)

        ' Handle permission requests (for camera, location, etc.)
        AddHandler WebView21.CoreWebView2.PermissionRequested, AddressOf HandlePermissionRequested
    End Sub

    ' Handle permission requests for camera, microphone, location, etc.
    Private Sub HandlePermissionRequested(sender As Object, e As CoreWebView2PermissionRequestedEventArgs)
        If e.PermissionKind = CoreWebView2PermissionKind.Camera OrElse
           e.PermissionKind = CoreWebView2PermissionKind.Geolocation Then
            ' Automatically allow camera and geolocation access (you can adjust based on requirements)
            e.State = CoreWebView2PermissionState.Allow
        Else
            ' Deny other permission requests
            e.State = CoreWebView2PermissionState.Deny
        End If
    End Sub

    ' Hide the cursor when the form is shown
    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        ' Hide the mouse cursor
        Cursor.Hide()
    End Sub

    ' Disable mouse movement and clicks
    Protected Overrides Sub OnMouseMove(e As MouseEventArgs)
        ' Prevent mouse from moving by locking it at a fixed point
        Cursor.Position = New Point(0, 0)
        MyBase.OnMouseMove(e)
    End Sub

    Protected Overrides Sub OnMouseDown(e As MouseEventArgs)
        ' Disable mouse clicks (do nothing when the mouse is clicked)
    End Sub

    Protected Overrides Sub OnMouseClick(e As MouseEventArgs)
        ' Disable mouse clicks (do nothing when the mouse is clicked)
    End Sub

    Protected Overrides Sub OnMouseWheel(e As MouseEventArgs)
        ' Disable mouse wheel scrolling (do nothing on scroll)
    End Sub

    ' Prevent the user from closing the form
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' Cancel the form close event
        e.Cancel = True
    End Sub

    ' Method to complete the exam and re-enable the mouse and Task Manager
    Private Sub ExamCompleted()
        ' Show the cursor when the exam is completed
        Cursor.Show()

        ' Close the form (end the exam)
        Application.Exit()
    End Sub
End Class
